import React from 'react'

export default function Error() {
    return (
        <div>
            Error 404 page
        </div>
    )
}
