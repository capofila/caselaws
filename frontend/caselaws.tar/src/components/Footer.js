import React from 'react';
import '../App.css';
function Footer() {
  return (
    <div className="row" id="copyright">

      <div className="col-md-12">

        <footer className="page-footer font-small">

          <div className="footer-copyright text-center py-3 h-10">

            © 2019 Copyright: Capofila

          </div>

        </footer>

      </div>

    </div>
  )
}
export default Footer;
